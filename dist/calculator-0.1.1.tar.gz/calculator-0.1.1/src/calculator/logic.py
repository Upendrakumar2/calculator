import calculator.logger

def add(a,b):
    return a+b

calculator.logger.log_class.add_done()

def subtract(a,b):
    return a-b

def multiply(a,b):
    return a*b

def divide(a,b):
    return a/b